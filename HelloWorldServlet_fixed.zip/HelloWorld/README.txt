===================================
COMP9321 Code Sample: HelloWorld
===================================

Description: Simple web application that shows takes in a name parameter and displays it with a greeting randomly drawn from a list. Demonstrates Servlet use and use of Filters.

Files:
src/ - Source files
.war - the war file for deploying in Tomcat
